/** Automatically generated file. DO NOT MODIFY */
package com.javacodegeeks.android.fragmentstest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}